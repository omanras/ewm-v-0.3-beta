#EMW v 0.3 beta
#using logic UAC No Cookies v 0.1
#programed by Majid AL-Maashari
#Email : omanras@gmail.com
#https://github.com/omanras
from bottle import route, run, template, static_file, get, post, request,os,FileUpload,redirect
import sqlite3 as sql
import hashlib
import pyexcel as pe
import re
import base64
import ast
import sys
reload(sys)
sys.setdefaultencoding('utf-8')
con = sql.connect("database2.db")  
con.text_factory = lambda x: unicode(x, 'utf-8', 'ignore')
cur = con.cursor()    
@get('/static/admin/vendor/bootstrap/css/<filepath:re:.*\.css>')
def send_css1(filepath):
    return static_file(filepath, root='./admin/vendor/bootstrap/css')
@get('/static/admin/vendor/metisMenu/<filepath:re:.*\.css>')
def send_css2(filepath):
    return static_file(filepath, root='./admin/vendor/metisMenu')
@get('/static/admin/dist/css/<filepath:re:.*\.css>')
def send_css3(filepath):
    return static_file(filepath, root='./admin/dist/css/')
@get('/static/admin/vendor/morrisjs/<filepath:re:.*\.css>')
def send_css4(filepath):
    return static_file(filepath, root='./admin/vendor/morrisjs')
@get('/static/admin/vendor/font-awesome/css/<filepath:re:.*\.css>')
def send_css5(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/css/')
@get('/static/admin/vendor/font-awesome/css/<filepath:re:.*\.css>')
def send_css6(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/css/')

#js Files :
@get('/static/admin/vendor/jquery/<filepath:re:.*\.js>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/jquery')

@get('/static/admin/vendor/bootstrap/js/<filepath:re:.*\.js>')
def send_js2(filepath):
    return static_file(filepath, root='./admin/vendor/bootstrap/js')

@get('/static/admin/vendor/metisMenu/<filepath:re:.*\.js>')
def send_js3(filepath):
    return static_file(filepath, root='./admin/vendor/metisMenu')

@get('/static/admin/vendor/raphael/<filepath:re:.*\.js>')
def send_js4(filepath):
    return static_file(filepath, root='./admin/vendor/raphael/')

@get('/static/admin/vendor/morrisjs/<filepath:re:.*\.js>')
def send_js5(filepath):
    return static_file(filepath, root='./admin/vendor/morrisjs/')

@get('/static/admin/data/<filepath:re:.*\.js>')
def send_js6(filepath):
    return static_file(filepath, root='./admin/data/')

@get('/static/admin/dist/js/<filepath:re:.*\.js>')
def send_js7(filepath):
    return static_file(filepath, root='./admin/dist/js/')
@get('/static/admin/vendor/jquery/<filepath:re:.*\.js>')
def send_js8(filepath):
    return static_file(filepath, root='./admin/vendor/jquery')

#Fonts files :
@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.eot>')
def send_font1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.woff2>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')


@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.woff>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')


@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.svg>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@get('/static/admin/vendor/font-awesome/fonts/<filepath:re:.*\.ttf>')
def send_js1(filepath):
    return static_file(filepath, root='./admin/vendor/font-awesome/fonts')

@route('/')
def index():    
    error = "no"
    return template('index.tpl',error = error)
def index2(error):
    return template('index.tpl',error = error)    

@route('/logout')
def logout():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token :
        return index()
    if token == "not ok":
        return index()    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        id = str(users[0][0])
        token = "not ok"
        ip = "not ok"
        cur.execute("UPDATE users SET token = ? , ip = ? WHERE id = ?",(token , ip,id))
        con.commit()
        error = "no"
        return home(token,error)
    else:
       return index()
@route('/usersdelete-all')
@post('/usersdelete-all')
def deleteusers():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    token = request.query.token
    error = "no"
    userid = request.POST.getall('userid')
    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        userID = str(users[0][0])
        groupID = users[0][3]
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == groupID :
                    if userid > 0 :
                        for iduser in userid :
                            if str(iduser) == str(groupID) :
                                error = "no_admin"
                                return deleteusers_error(error,token)
                            else :    
                                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(iduser,groupID)) 
                                con.commit()
                        error = "yes"
                        return deleteusers_error(error,token)        
    else :
        return index()                             
def deleteusers_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        return template('deleteusers-all.tpl',token = token ,error = error, users = users)
    else :
        return index()
@route('/userdelete')
def user_delete():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users:
        if str(users[0][0]) == users[0][3]:
            if userid == str(users[0][3]):
                error = "admin_user"
                return user_deleteerror(error,token)
            else :
                groupID = users[0][3]
                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(userid,groupID))
                con.commit()
                error = "yes"
                return user_deleteerror(error,token)             
        else :
            return home(token,error)        
    else :
        return index()            
def user_deleteerror(error,token):
    
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')

    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()        
    if users :
        if str(users[0][0]) == users[0][3]:
            return template('deleteusers-all.tpl',token = token ,error = error, users = users)
        else :
            error = "no"
            return home(token,error)   

    else :
        return index()    
@route('/users')
def users():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            return template('users.tpl',token = token,error = error,users = users)
    else :
        return index()        
@post('/users')
def adduser():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    groupID = users[0][3]
    groupName = users[0][5]
    if str(users[0][0]) == users[0][3]:
        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        if not username :
            error = "no_user"
            return adduser_error(error,token)
        if not password :
            error = "no_password"
            return adduser_error(error,token)
        if not email :
            error = "no_email"
            return adduser_error(error,token) 
        else :
            cur.execute("SELECT username FROM users WHERE username = ?",[username])
            users = cur.fetchall()
            if users :
                error = "used_user"
                return adduser_error(error,token)
            cur.execute("SELECT email FROM users WHERE email = ?",[email])  
            users = cur.fetchall()
            if users :
                error = "used_email"
                return adduser_error(error,token)  
            else :
                password = hashlib.md5(password).hexdigest()
                tokenpass = "not ok"  
                cur.execute("INSERT INTO users (username,password,groupID,email,groupName,token) VALUES (?,?,?,?,?,?)",(username,password,groupID,email,groupName,tokenpass))
                con.commit()
                
                error = "yes"
                return adduser_error(error,token)
    else :
        return home(token,error)
def adduser_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if str(users[0][0]) == users[0][3]:
        return template('users.tpl',error = error,token = token,users = users)
@route('/groupedit')
def group_name():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not token:
        return index()
    if not ip :
        return index()
    if not userid :
        return home(token,error)
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[userid])
            usersinfo = cur.fetchall()
            if usersinfo :
                return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
            else :
                return home(token,error)    

    else :
        return home(token,error)
@post('/groupedit')
def group_name_change():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    groupname = request.forms.get('groupname')
    error = "no"
    if not token:
        return index()
    if not ip :
        return index()
    if not userid :
        return home(token,error)
   
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":

            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[userid])
            usersinfo = cur.fetchall()
            if usersinfo :
                if not groupname :
                    error = "no_name"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
                cur.execute("SELECT groupName FROM users WHERE groupName = ?",[groupname])
                groupcheck = cur.fetchall()
                if groupcheck :
                    error = "group_used"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
                else :    
                    cur.execute("UPDATE users SET groupName = ? WHERE groupID = ?",(groupname,userid))
                    con.commit()
                    error = "yes"
                    return template('groupedit.tpl',token = token , users = users,usersinfo = usersinfo,error = error)
            else :
                return home(token,error)    

    else :
        return home(token,error)

@route('/adduser-group')
def adduser_group():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :    
        if str(users[0][0]) == "1" :
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[userid])
            group_name = cur.fetchall()
            groupname = str(group_name[0][0])
            return template('adduser-group.tpl',users = users,userid = userid ,error = error,token = token,groupname = groupname)
        else :
            return home(token,error)
    else :
        return home(token,error)       

@post('/adduser-group')
def adduser_group_admin():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token.error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":

        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        cur.execute("SELECT groupName FROM users WHERE groupID = ?",[userid])
        group_name = cur.fetchall()
        groupname = group_name[0][0]
        if not username :
            error = "no_user"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
        if not password :
            error = "no_password"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
        if not email :
            error = "no_email"
            return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)

        else :
            cur.execute("SELECT username FROM users WHERE username = ?",[username])
            userscheck = cur.fetchall()
            if userscheck :
                error = "used_user"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
            cur.execute("SELECT email FROM users WHERE email = ?",[email])  
            userscheck = cur.fetchall()
            if userscheck :
                error = "used_email"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname) 
            else :
                password = hashlib.md5(password).hexdigest()
                tokenpass = "not ok" 
                cur.execute("INSERT INTO users (username,password,groupID,email,groupName,token) VALUES (?,?,?,?,?,?)",(username,password,userid,email,groupname,tokenpass))
                con.commit()
                error = "yes"
                return template('adduser-group.tpl',users = users, token = token ,userid = userid,error = error ,groupname = groupname)
    else :
        return home(token,error)
@route('/usersdelete-all-group')
@post('/usersdelete-all-group')
def usersdelete_all_group():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.POST.getall('userid')
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":
        userID = str(users[0][0])
        
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == "1" :
                    if userid > 0 :
                        for iduser in userid :
                            if str(iduser) == str(groupID) :
                                error = "no_admin"
                                return deleteusers_error(error,token)
                            else :    
                                cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(iduser,groupID)) 
                                con.commit()
                        error = "yes_group"
                        return deleteusers_error(error,token)
    else :
        return home(token,error)                        
@route('/userdelete-gorup')
def userdelete_gorup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.query.userid
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()

    if str(users[0][0]) == "1":
        userID = str(users[0][0])
        
        if not token :
            return home(token,error)
        if not userid :
            error = "no_userid"
            return deleteusers_error(error,token)
        else :    
 
            if users :
                if userID == "1" :
                
                        
                    if userid == str(groupID) :
                        error = "no_admin"
                        return deleteusers_error(error,token)
                    else :    
                        cur.execute("DELETE FROM users WHERE id = ? and groupID = ?",(userid,groupID)) 
                        con.commit()
                        error = "yes_group"
                        return deleteusers_error(error,token)
    else :
        return home(token,error)        
@route('/changeadmin-group')
def changeadmin_group():

    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            
            return template('changeadmin-group.tpl',token = token,users = users,usersinfo = usersinfo,error = error)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/changeadmin-group')
def change_admin():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    userid = request.forms.get('userid')
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if not userid :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)
    if userid == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            cur.execute("UPDATE users SET groupID = ? WHERE groupID = ?",(userid,groupID))
            con.commit()
            cur.execute("UPDATE table_name SET groupID = ? WHERE groupID = ?",(userid,groupID))
            con.commit()
            cur.execute("SELECT * FROM sheets WHERE groupID = ?",[groupID])
            sheets = cur.fetchall()
            if sheets :
                for i in sheets :
                    sheetname = base64.b64encode(str(i[0]) + str(i[1]) + str(i[2]))
                    sheetname2 = base64.b64encode(str(i[0]) + str(i[1]) + userid)
                    query = "ALTER TABLE '" + sheetname +"' RENAME TO '" + sheetname2 + "'"
                    cur.execute(query)
                    con.commit()
            cur.execute("UPDATE sheets SET groupID = ? WHERE groupID = ?",(userid,groupID))
            con.commit()
            error = "yes"           
            return template('changeadmin-group.tpl',token = token,users = users,usersinfo = usersinfo,error = error)
        else :
            return home(token,error)    
    else :
        return home(token,error)    
@route('/group-delete')
def group_delete():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()    
            
            return template('group-delete.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/group-delete')    
def delete_group() :
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    groupID = request.query.id
    error = "no"
    check = request.forms.get("check")

    if not ip :
        return index()
    
    if not token:
        return index()

    if not groupID :
        return home(token,error)
    if groupID == "1" :
        return home(token,error)
    if not check :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            
            cur.execute("SELECT groupName FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            if check == "yes" :
                cur.execute("DELETE FROM users WHERE groupID = ?",[groupID])
                con.commit()
                cur.execute("SELECT * FROM table_name WHERE groupID = ?",[groupID])
                tablename = cur.fetchall()
                if tablename :
                    cur.execute("DELETE FROM table_name WHERE groupID = ?",[groupID])
                    con.commit()
                cur.execute("SELECT * FROM sheets WHERE groupID = ?",[groupID])
                sheets = cur.fetchall()
                if sheets :
                    for i in sheets :
                        sheetname = base64.b64encode(str(i[0]) + str(i[1]) + str(i[2]))
                        query = "DROP TABLE '" + sheetname + "'"
                        cur.execute(query)
                        con.commit()
                    cur.execute("DELETE FROM sheets WHERE groupID = ?",[groupID])
                    con.commit()    
                error = "yes"
                return template('group-delete.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo)
            else :
                return home(token,error)    
        else :
            return home(token,error)    
    else :
        return home(token,error)    
@route('/useredit-group')
def useredit_group():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userID = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not userID :
        return home(token,error)
    if userID == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            cur.execute("SELECT * FROM users WHERE id = ?",[userID])
            usersinfo = cur.fetchall()   
            groupID = str(usersinfo[0][1])
            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/useredit-group')
def useredit_group2():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    error = "no"
    if not ip :
        return index()
    
    if not token:
        return index()

    if not userid :
        return home(token,error)
    if userid == "1" :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            username = request.forms.get('user')
            password = request.forms.get('password')
            email = request.forms.get('email')
            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
            usersinfo = cur.fetchall()
            groupID = str(usersinfo[0][3])
            userID = userid
            if usersinfo :
                if not username :
                    error = "no_user"
                    return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
                if not email :
                    error = "no_email"
                    return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)    
                else :
                    if username == usersinfo[0][1] and email == usersinfo[0][4]:
                        if not password :
                            error = "no_password"
                            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
                            usersinfo = cur.fetchall()
                            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
                        password = hashlib.md5(password).hexdigest()
                        cur.execute("UPDATE users SET password = ? WHERE id = ? and username = ?",(password,userid,username))
                        con.commit()
                        error = "yes"
                        return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
                    if usersinfo[0][1] != username:

                        cur.execute("SELECT username FROM users WHERE username = ?",[username])
                        usersinfo = cur.fetchall()
                        if usersinfo :
                            error = "used_user"
                            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
                            usersinfo = cur.fetchall()
                            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
                        else :
                            cur.execute("UPDATE users SET username = ? WHERE id = ? and groupID = ?",(username,userid,groupID))
                            con.commit()
                            error = "yes"
                            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
                            usersinfo = cur.fetchall()
                            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)    
                    if usersinfo[0][4] != email :
                        cur.execute("SELECT email FROM users WHERE email = ?",[email])  
                        usersinfo = cur.fetchall() 
                        if usersinfo :
                            error = "used_email"
                            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
                            usersinfo = cur.fetchall()
                            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)
                        else :
                            cur.execute("UPDATE users SET email = ? WHERE id = ? and groupID = ?",(email,userid,groupID))
                            con.commit()
                            cur.execute("SELECT * FROM users WHERE id = ?",[userid])
                            usersinfo = cur.fetchall()
                            error = "yes"
                            return template('useredit-group.tpl',token = token,users = users,groupID = groupID,error = error,usersinfo = usersinfo,userID = userID)  
                    else :
                        return home(token,error)
            else :
                return home(token,error)        
    else :
        return index()      
@route('/userinfo')
def userinfo():

    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? and ip = ?",(token,ip))
    users = cur.fetchall()

    if users :
        groupID = users[0][3]
        groupName = users[0][5]
        return template('userinfo.tpl',token = token, error = error,users = users)
    else:
        return index()    
@post('/userinfo')
def userinfo_update():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        
        groupID = users[0][3]
        groupName = users[0][5]
        passwordcheck = users[0][2]
        username = request.forms.get('user')
        password = request.forms.get('password')
        email = request.forms.get('email')
        if not username :
            error = "no_user"
            return userinfo_error(error,token)
        if not password :
            error = "no_password"
            return userinfo_error(error,token)
        if not email :
            error = "no_email"
            return userinfo_error(error,token) 
        else :
            if username == users[0][1] and email == users[0][4]:
                password = hashlib.md5(password).hexdigest()
                cur.execute("UPDATE users SET password = ? WHERE token = ? and username = ?",(password,token,username))
                con.commit()
                error = "yes"
                return userinfo_error(error,token)
            if users[0][1] != username:

                cur.execute("SELECT username,password FROM users WHERE username = ?",[username])
                users = cur.fetchall()
                if users :
                    error = "used_user"
                    return userinfo_error(error,token)
                else :
                    password = hashlib.md5(password).hexdigest()
                    
                    if password == passwordcheck :
                        cur.execute("UPDATE users SET username = ? WHERE token = ? and password = ?",(username,token,password))
                        con.commit()
                        error = "yes"
                        return userinfo_error(error,token)
                    else :
                        error = "wrong_password"
                        return userinfo_error(error,token)    
            if users[0][4] != email :
                cur.execute("SELECT email,password FROM users WHERE email = ?",[email])  
                users = cur.fetchall() 
                if users :
                    error = "used_email"
                    return userinfo_error(error,token)
                else :
                    password = hashlib.md5(password).hexdigest()
                    
                    if password == passwordcheck :
                        cur.execute("UPDATE users SET email = ? WHERE token = ? and password = ?",(email,token,password))
                        con.commit()
                        error = "yes"
                        return userinfo_error(error,token)
                    else :
                        error = "wrong_password"
                        return userinfo_error(error,token)  
            else :
                return home(token,error)
    else :
        return index()       
def userinfo_error(error,token):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()


    if users :
        return template('userinfo.tpl',error = error,token = token,users = users)
    else:
        return home(token,error)    
@route('/useredit')
def useredit():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id

    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        if str(users[0][0]) == str(users[0][3]):
            groupID = users[0][3]
            cur.execute("SELECT id,username,email FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
            usersinfo = cur.fetchall()
            return template('useredit.tpl',userid = userid,users = users,usersinfo = usersinfo,token = token,error = error)
        else :
            return home(token,error)   
    else :
        return index()
@post('/useredit')
def userinfo_update():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    userid = request.query.id
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    if not userid :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()    
    if users:
        if str(users[0][0]) == users[0][3]:

            groupID = users[0][3]
            groupName = users[0][5]
            username = request.forms.get('user')
            password = request.forms.get('password')
            email = request.forms.get('email')
            cur.execute("SELECT * FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
            usersinfo = cur.fetchall()
            if usersinfo :
                if not username :
                    error = "no_user"
                    return useredit_error(error,token,userid)
                if not email :
                    error = "no_email"
                    return useredit_error(error,token,userid) 
                else :
                    if username == usersinfo[0][1] and email == usersinfo[0][4]:
                        if not password :
                            error = "no_password"
                            return useredit_error(error,token,userid)
                        password = hashlib.md5(password).hexdigest()
                        cur.execute("UPDATE users SET password = ? WHERE id = ? and username = ?",(password,userid,username))
                        con.commit()
                        error = "yes"
                        return useredit_error(error,token,userid)
                    if usersinfo[0][1] != username:

                        cur.execute("SELECT username FROM users WHERE username = ?",[username])
                        usersinfo = cur.fetchall()
                        if usersinfo :
                            error = "used_user"
                            return useredit_error(error,token,userid)
                        else :
                            cur.execute("UPDATE users SET username = ? WHERE id = ? and groupID = ?",(username,userid,groupID))
                            con.commit()
                            error = "yes"
                            return useredit_error(error,token,userid)    
                    if usersinfo[0][4] != email :
                        cur.execute("SELECT email FROM users WHERE email = ?",[email])  
                        usersinfo = cur.fetchall() 
                        if usersinfo :
                            error = "used_email"
                            return useredit_error(error,token,userid)
                        else :
                            cur.execute("UPDATE users SET email = ? WHERE id = ? and groupID = ?",(email,userid,groupID))
                            con.commit()
                            error = "yes"
                            return useredit_error(error,token,userid)
  
                    else :
                        return home(token,error)
            else :
                return home(token,error)        
    else :
        return index()    
def useredit_error(error,token,userid) :
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index() 
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()


    if users :
        groupID = str(users[0][3])
        cur.execute("SELECT id,username,email FROM users WHERE id = ? AND groupID = ?",(userid,groupID))
        usersinfo = cur.fetchall()
        return template('useredit.tpl',error = error,token = token,users = users,userid = userid,usersinfo = usersinfo)
    else:
        return home(token,error)
@route('/userscp')
def userscp():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            return template('userscp.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
        else :
            return home(token,error)
    else :
        return index()       
@route('/creategroup')
def creategroup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == "1":
            return template('creategroup.tpl',token = token,error = error, users = users)
        else :
            return home(token,error)
    else :
        return index()       
@post('/creategroup')
def addgroup():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not ip :
        return index()
    error = "no"
    if not token:
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        if str(users[0][0]) == "1":
            groupname = request.forms.get('groupname')
            username = request.forms.get('user')
            password = request.forms.get('password')
            email = request.forms.get('email')
            if not groupname :
                error = "no_group"
                return addgroup_error(error,token)
            if not username :
                error = "no_user"
                return addgroup_error(error,token)
            if not password :
                error = "no_password"
                return addgroup_error(error,token)
            if not email :
                error = "no_email"
                return addgroup_error(error,token) 
            else :
                cur.execute("SELECT groupName FROM users WHERE groupName = ?",[groupname])
                users = cur.fetchall()
                if users :
                    error = "used_group"
                    return addgroup_error(error,token)
                cur.execute("SELECT username FROM users WHERE username = ?",[username])
                users = cur.fetchall()
                if users :
                    error = "used_user"
                    return addgroup_error(error,token)
                cur.execute("SELECT email FROM users WHERE email = ?",[email])  
                users = cur.fetchall()
                if users :
                    error = "used_email"
                    return addgroup_error(error,token)  
                else :
                    password = hashlib.md5(password).hexdigest()
                    tokenpass = "not ok"
                    cur.execute("INSERT INTO users (username,password,email,groupName,token) VALUES (?,?,?,?,?)",(username,password,email,groupname,tokenpass))
                    con.commit()
                    cur.execute("SELECT id FROM users WHERE username = ? and password = ? and groupName = ?",(username,password,groupname))
                    users = cur.fetchall()
                    id = str(users[0][0])
                    groupID = str(users[0][0])
                    if users:
                        cur.execute("UPDATE users SET groupID = ? WHERE id = ?",(groupID,id))
                        con.commit()
                        error = "yes"
                        return addgroup_error(error,token)
                    else:
                        return home(token,error)    
        else :
            return home(token,error)
    else :
        return index()        
def addgroup_error(error,token):

    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if str(users[0][0]) == "1":
        return template('creategroup.tpl',error = error,token = token,users = users)
    else :
        return home(token,error)    
@route('/groups-manage')
def groups_manage():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if not ip :
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == "1":
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE id = groupID")
            groupusers = cur.fetchall()
            return template('groups-manage.tpl',users = users ,groupusers = groupusers,token = token)
        else :
            return home(token,error)   
    else :
        return home(token,error)        
    
    cur.execute("")
@route('/home')
def home(token,error):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token:
        return index()
    if token == "not ok" :
        return index()
    else :    
        cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
        users = cur.fetchall()
    if error == "no" :
        if users :
           groupID = str(users[0][3])
           if str(users[0][7]) == ip :
            cur.execute("SELECT tableName FROM table_name WHERE groupID = ?",[groupID])
            data = cur.fetchall()    
            return template('home.tpl',token = token,users = users,data = data)
           else :
            return index()   
    else :
        return index2(error)
@get('/home')
def gethome():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token:
        return index()
    if token == "not ok":
        return index()
    error = "no"
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :

        return home(token,error)
    else :
        return index()        

#EWM PART :
@route('/create-table')
def create_table():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    tablename = request.forms.get('tablename')
    upload = request.forms.get('upload')
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            return template('create-table.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
        else :
            return home(token,error)
    else :
        return index()
@route('/upload')
def up_load():
    error = "no"
    token = request.query.token
    if not token :
        return index()    
    return home(token,error)

@post('/upload')
def do_upload():
    error = "no"
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.forms.get('tablename')
    upload = request.files.get('upload')
    if not upload :
        return home(token,error)
    name, ext = os.path.splitext(upload.filename)
    
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            if not tablename :
                error ="no_tablename"
                return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
            cur.execute("SELECT tableName FROM table_name WHERE tableName=? AND groupID=?",(tablename,groupID))
            table_check = cur.fetchall()
            if table_check:
                error = "tablename"
                return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users)

            cur.execute("INSERT INTO table_name (tableName,groupID) VALUES (?,?)",(tablename,groupID))
            con.commit()
            if ext not in ('.xls','.xlsx'):
                error = "not-allow"
                return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
            save_path = 'tmp/'
            upload.filename = 'test' + base64.b64encode(groupID)+ ext  
            upload.save(save_path)
            cur.execute("SELECT tableID FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
            tableID = cur.fetchall()
            tableID = str(tableID[0][0])
            sheet = pe.get_book(file_name='tmp/'+ upload.filename)
            sheetname = list(sheet.sheet_names())
            data = []
            for k in sheetname :
                pe.save_as(array=sheet[k],dest_file_name='tmp/'+base64.b64encode('test'+groupID)+ ".csv")
                cur.execute("INSERT INTO sheets (tableID,sheetName,groupID) VALUES (?,?,?)",(tableID,str(sheet[k].name),groupID))
                con.commit()
                tablename = tableID + str(sheet[k].name) + groupID
                with open('tmp/' + base64.b64encode('test'+groupID)+ ".csv") as f :
                    array = []
                    for line in f :
                        array.append(line)
                    if len(array) == 0 :
                        error = "empty_sheet"
                        q = "DELETE FROM sheets WHERE sheetName = '" + str(sheet[k].name) +"' AND tableID = '" + tableID + "'"
                        cur.execute(q)
                        con.commit()
                        os.remove('tmp/'+base64.b64encode('test'+groupID)+ '.csv')
                        os.remove('tmp/'+ upload.filename)
                        return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users,tablename = tablename) 
                    iix = str(array[0])
                    iix = iix.split(',')
                    ii = []
                    for x in iix :
                        x = x.replace('\r\n','')
                        ii.append(x)
                    dup_items = set()
                    uniq_items = []
                    for x in ii :
                        if x not in dup_items:
                            uniq_items.append(x)
                            dup_items.add(x)        
                    if len(dup_items) != len(ii):
                        error = "match_cols"
                        q = "DELETE FROM sheets WHERE tableID = '" + tableID +"'"
                        cur.execute(q)
                        con.commit()
                        q = "DELETE FROM table_name WHERE tableID ="+ tableID
                        cur.execute(q)
                        con.commit()
                        os.remove('tmp/'+base64.b64encode('test'+groupID)+ '.csv')
                        os.remove('tmp/'+ upload.filename)
                        return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users,tablename = tablename)       
                    for i in range(int(len(array))) :
                        if i == 0 :
                            l = re.findall(r'"(.*?)"',array[0])
                            x = array[0].split('"')
                            for q in range(int(len(x))):
                                for a in l + x :
                                    if a not in l or a not in x:
                                         if str(x[q]) == a :
                                              x[q] = a.replace(',','" TEXT,"')
                                    if a in l or a in x :
                                        if str(x[q]) == a :
                                            x[q] = a
                            ii = ''
                            for i in x :
                                ii = ii + i    
                            query = 'CREATE TABLE IF NOT EXISTS "' + base64.b64encode(tablename) + '" (rowID INTEGER PRIMARY KEY AUTOINCREMENT, "' + str(ii) + '" TEXT)'
                            cur.execute(query)
                            con.commit()
                        else :
                            l = re.findall(r'"(.*?)"',array[i])
                            x = array[i].split('"')
                            for q in range(int(len(x))):
                                for a in l + x :
                                    if a not in l or a not in x:
                                        if str(x[q]) == a :
                                            x[q] = a.replace(',','","')
                                    if a in l or a in x :
                                        if str(x[q]) == a :
                                            x[q] = a
                            ii = ''
                            for i in x :
                                ii = ii + i    
                            query = 'INSERT INTO "' + base64.b64encode(tablename) + '" VALUES (null,"' + str(ii) + '")'
                            cur.execute(query)
                            con.commit()
                os.remove('tmp/'+base64.b64encode('test'+groupID)+ '.csv')
            os.remove('tmp/'+ upload.filename)
            error = "yes"                
            return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
        else :
            return home(token,error)
    else :
        return index() 
@route('/create-table2')
def do_create():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
        else :
            return home(token,error)
    else :
        return index()
@route('/create-one')
@post('/create-one')
def create_one():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.forms.get('tablename')
    sheets = request.forms.get('sheets')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            if not tablename :
                error = 'no_tablename'
                return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
            if not sheets :
                error = "no_sheets" 
                return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
            if sheets == '0' :
                error = "no_sheets"  
                return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)      
            if sheets.isdigit() == False:
                
                error = "no_sheets"  
                return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)     
            else :
                cur.execute("SELECT * FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
                check = cur.fetchall()
                if check :
                    error = "used_table"
                    return template('create-table2.tpl',token = token,error = error,usersinfo = usersinfo,users = users)
                else:    
                    return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 
        else :
            return home(token,error)
    else :
        return index()
@route('/create-two')
@post('/create-two')
def create_two():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.forms.get('tablename')
    sheets = request.forms.get('sheets')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()


    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    
    if users :
        groupID = users[0][3]
        if str(users[0][0]) == users[0][3] :
            cur.execute("SELECT id,username,groupName,groupID FROM users WHERE groupID = ?",[groupID])
            usersinfo = cur.fetchall()
            tablename = request.query.tablename
            sheets = request.forms.getall('sheets')
            cols = request.forms.getall('cols')
            if not tablename :
                sheets = int(len(sheets))
                error = "no_tablename"
                return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 
            cur.execute("SELECT * FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
            check = cur.fetchall()
            if check :
                sheets = int(len(sheets))
                error = "used_tablename"
                return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 
    
            if not sheets:
                sheets = int(len(sheets))
                error = "no_sheets"
                return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 

            if int(len(cols)) == 0 :
                sheets = int(len(sheets))
                error = "no_cols"
                return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 
            else :
                for i in range(int(len(sheets))):
                    if not str(sheets[i]):
                        sheets = int(len(sheets))
                        error = "no_sheets"
                        return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename) 
                    if not str(cols[i]):         
                        sheets = int(len(sheets))
                        error = "no_cols"
                        return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename)
                        
                    ii = cols[i].split(',')
                    dup_items = set()
                    uniq_items = []
                    for x in ii :
                        if x not in dup_items:
                            uniq_items.append(x)
                            dup_items.add(x)        
                    if len(dup_items) != len(ii):
                        error = "match_cols"
                        sheets = int(len(sheets))
                        return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename)
                    if int(len(sheets)) > 1 :    
                        ii = sheets
                        ii = all(x == ii[0] for x in ii)
                        if ii == True :
                            error = "match_sheets"
                            sheets = int(len(sheets))
                            return template('create-two.tpl',token = token,error = error,usersinfo = usersinfo,users = users,sheets = sheets,tablename = tablename)
                cur.execute("INSERT INTO table_name (tableName,groupID) VALUES (?,?)",(tablename,groupID))
                con.commit()
                cur.execute("SELECT tableID FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
                q = cur.fetchall()
                if q :
                    tableID = str(q[0][0])
                else :
                    error = "no"
                    return home(token,error) 
            
                for i in range(int(len(sheets))):    
 
                    cur.execute("INSERT INTO sheets (tableID,sheetName,groupID) VALUES (?,?,?)",(tableID,str(sheets[i]),groupID))
                    con.commit()                        
                    tablename = tableID +str(sheets[i]) + groupID
                    tablename = base64.b64encode(tablename)
                    colsname = cols[i].replace(',',"' TEXT, '")
                    #query = "CREATE TABLE IF NOT EXISTS '" +tablename + "' (rowID INTEGER PRIMARY KEY AUTOINCREMENT,'" + colsname + "' TEXT)"
                    #cur.execute(query)
                    colsname = "'" + colsname + "' TEXT"
                    query = "CREATE TABLE IF NOT EXISTS '" +tablename + "' (rowID INTEGER PRIMARY KEY AUTOINCREMENT,{})".format(colsname)
                    cur.execute(query)
                    con.commit()
                error = "yes"
                return template('upload.tpl',token = token,error = error,usersinfo = usersinfo,users = users)  
@route('/table-view')
def table_view():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT tableID FROM table_name WHERE tablename = ? AND groupID = ?",(tablename,groupID))
        tableID = cur.fetchall()
        if tableID :
            tableID = str(tableID[0][0])
            cur.execute("SELECT sheetName FROM sheets WHERE tableID = ? AND groupID =?",(tableID,groupID))
            sheetname = cur.fetchall()
            if sheetname :
                tablename = base64.b64encode(tableID + str(sheetname[0][0]) + groupID)
                query = "SELECT * FROM '" + tablename + "'"
                cur.execute(query)
                data = cur.fetchall()
                query = "PRAGMA table_info('"+ tablename +"')"
                cur.execute(query)
                cols = cur.fetchall()
                return template("table-view.tpl",users = users , error = error,token = token,sheetname = sheetname,data = data,cols = cols,tablename=tablename2,tableID = tableID,groupID = groupID)
            else :
                return template('no-sheets',token = token,error = error,users = users)    
        else :
            return home(token,error)
@route('/tmp/<filename:path>')
def download(token,tableID,error,filename):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token :
        return home(token,error)
    if not error :
        return home(token,error)
    if not filename :
        return home(token,error)    
    if error == "yes" :
        cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
        users = cur.fetchall()   
        if users :
            groupID = users[0][3]
            cur.execute("SELECT tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            check = cur.fetchall()
            if check :
                file_check = str(check[0][0]) + '-'+ str(tableID) + '.xls'
                if filename == file_check :    
                    return static_file(filename,root='tmp/',download=filename)
                else:
                    return home(token,error)
            else :
                return home(token,error)        
    else : 
        return home(token,error)
def download2(token,sheetname,tableID,error,filename):
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    if not token :
        return home(token,error)
    if not sheetname :
        return home(token,error)
    if not error :
        return home(token,error)
    if not filename :
        return home(token,error)    
    if error == "yes" :
        cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
        users = cur.fetchall()   
        if users :
            groupID = users[0][3]
            cur.execute("SELECT tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            check = cur.fetchall()
            if check :
                file_check = 'tmp/' + str(check[0][0]) + '-'+ sheetname + '.xls.sortable.html'
                if filename == file_check :
                    filename = filename.replace('tmp/','')   
                    return static_file(filename,root='tmp/',download=filename)
                else:
                    return home(token,error)
            else :
                return home(token,error)        
    else : 
        return home(token,error)         
@route('/download-table')
def download_table():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tableID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
        check = cur.fetchall()
        if check:
            tablename2 = str(check[0][1])
            cur.execute("SELECT sheetName FROM sheets WHERE tableID=? AND groupID=?",(tableID,groupID))
            sheetname = cur.fetchall()
            sheets = []
            for x in sheetname :
                sheets.append(str(x[0])) 
            content = ''
            ii = ''
            for i in range(int(len(sheets))):
                cols = []
                tablename = base64.b64encode(str(tableID)+str(sheets[i])+str(groupID))
                query = "PRAGMA table_info('"+ tablename +"')"
                cur.execute(query)
                col = cur.fetchall()
                for x in col :
                    if str(x[1]) != 'rowID' :
                        cols.append(str(x[1]))        
                query = "SELECT * FROM '"+tablename+"'"
                cur.execute(query)
                data = cur.fetchall()
                array2 = []
                for x in data :
                    array = []
                    for k in range(int(len(x))) :
                        if str(x[0]) != str(x[k]):
                            array.append(str(x[k]))
                    array2.append(array)
                array3 = []   
                for c in cols :
                    array3.append(str(c))
                array2.insert(0,array3)   
                content = "'" + str(sheets[i]) +"'" + ":" + str(array2)    
                ii = ii + content + ','
            ii = ii[:-1]
            ii = '{' + ii + '}'
            ii = ast.literal_eval(ii)
            content = ii
            filename2 = tablename2 + '-' + tableID + '.xls'
            a_dictinoary_of_two_dimesional_arrays = content
            pe.save_book_as(bookdict=a_dictinoary_of_two_dimesional_arrays,dest_file_name="tmp/"+filename2)
            error = "yes"
            return download(token,tableID,error,filename2)
        else:
            return home(token,error)
    else :
        return home(token,error)        
@route('/view-mode')
def view_mode():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tableID = request.query.id
    sheet = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheet :
        return home(token,error)   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
        check = cur.fetchall()
        if check:
            tablename2 = str(check[0][1])
            cur.execute("SELECT sheetName FROM sheets WHERE tableID=? AND groupID=?",(tableID,groupID))
            sheetname = cur.fetchall()
            sheets = []
            for x in sheetname :
                if base64.b64encode(tableID + str(x[0]) + groupID) == str(sheet) :
                    sheets.append(str(x[0]))
            if base64.b64encode(tableID + str(sheets[0]) + groupID) != sheet :
                return home(token,error)         
            content = ''
            ii = ''
            for i in range(int(len(sheets))):
                cols = []
                tablename = base64.b64encode(str(tableID)+str(sheets[i])+str(groupID))
                query = "PRAGMA table_info('"+ tablename +"')"
                cur.execute(query)
                col = cur.fetchall()
                for x in col :
                    if str(x[1]) != 'rowID' :
                        cols.append(str(x[1]))        
                query = "SELECT * FROM '"+tablename+"'"
                cur.execute(query)
                data = cur.fetchall()
                array2 = []
                for x in data :
                    array = []
                    for k in range(int(len(x))) :
                        if str(x[0]) != str(x[k]):
                            array.append(str(x[k]))
                    array2.append(array)
                array3 = []   
                for c in cols :
                    array3.append(str(c))
                array2.insert(0,array3)   
                content = "'" + str(sheets[i]) +"'" + ":" + str(array2)    
                ii = ii + content + ','
            ii = ii[:-1]
            ii = '{' + ii + '}'
            ii = ast.literal_eval(ii)
            content = ii
            #filename2 = tablename2 + '-' + str(sheets[0]) + '.xls'
            filename2 = filename2 = tablename2 + str(sheets[0])
            filename2 =hashlib.md5(filename2).hexdigest()
            filename2 = filename2 + '.xls'
            a_dictinoary_of_two_dimesional_arrays = content
            pe.save_book_as(bookdict=a_dictinoary_of_two_dimesional_arrays,dest_file_name="tmp/"+filename2)
            sheet = pe.get_sheet(file_name = 'tmp/'+filename2)
            filename2 = 'tmp/'+filename2+'.sortable.html'
            load = sheet.save_as(filename2,display_length=10)
            return template(filename2)
        else:
            return home(token,error)
    else :
        return home(token,error)
@route('/download-html')
def download_html():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tableID = request.query.id
    sheet = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheet :
        return home(token,error)   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
        check = cur.fetchall()
        if check:
            tablename2 = str(check[0][1])
            cur.execute("SELECT sheetName FROM sheets WHERE tableID=? AND groupID=?",(tableID,groupID))
            sheetname = cur.fetchall()
            sheets = []
            for x in sheetname :
                if base64.b64encode(tableID + str(x[0]) + groupID) == str(sheet) :
                    sheets.append(str(x[0]))
            if base64.b64encode(tableID + str(sheets[0]) + groupID) != sheet :
                return home(token,error)         
            content = ''
            ii = ''
            for i in range(int(len(sheets))):
                cols = []
                tablename = base64.b64encode(str(tableID)+str(sheets[i])+str(groupID))
                query = "PRAGMA table_info('"+ tablename +"')"
                cur.execute(query)
                col = cur.fetchall()
                for x in col :
                    if str(x[1]) != 'rowID' :
                        cols.append(str(x[1]))        
                query = "SELECT * FROM '"+tablename+"'"
                cur.execute(query)
                data = cur.fetchall()
                array2 = []
                for x in data :
                    array = []
                    for k in range(int(len(x))) :
                        if str(x[0]) != str(x[k]):
                            array.append(str(x[k]))
                    array2.append(array)
                array3 = []   
                for c in cols :
                    array3.append(str(c))
                array2.insert(0,array3)   
                content = "'" + str(sheets[i]) +"'" + ":" + str(array2)    
                ii = ii + content + ','
            ii = ii[:-1]
            ii = '{' + ii + '}'
            ii = ast.literal_eval(ii)
            content = ii
            filename2 = tablename2 + '-' + str(sheets[0]) + '.xls'
            a_dictinoary_of_two_dimesional_arrays = content
            pe.save_book_as(bookdict=a_dictinoary_of_two_dimesional_arrays,dest_file_name="tmp/"+filename2)
            sheet = pe.get_sheet(file_name = 'tmp/'+filename2)
            filename2 = 'tmp/'+filename2+'.sortable.html'
            load = sheet.save_as(filename2,display_length=10)
            error = "yes"
            sheetname = str(sheets[0])
            return download2(token,sheetname,tableID,error,filename2)
        else:
            return home(token,error)
    else :
        return home(token,error)            
@route('/sheet-view')
def sheet_view():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT tableID FROM table_name WHERE tablename = ? AND groupID = ?",(tablename,groupID))
        tableID = cur.fetchall()
        if tableID :
            tableID = str(tableID[0][0])
            cur.execute("SELECT sheetName FROM sheets WHERE tableID = ? AND groupID =?",(tableID,groupID))
            sheetname = cur.fetchall()
            tablename = sheet
            query = "SELECT * FROM '" + tablename + "'"
            cur.execute(query)
            data = cur.fetchall()
            query = "PRAGMA table_info('"+ tablename +"')"
            cur.execute(query)
            cols = cur.fetchall()
            return template("sheet-view.tpl",users = users , error = error,token = token,sheetname = sheetname,data = data,cols = cols,tablename=tablename2 ,sheet = sheet,tableID = tableID,groupID = groupID)    
        else :
            return home(token,error)
@route('/sheet-search')
@post('/sheet-search')
def sheet_search():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    sheet = request.query.sheet
    search = request.forms.get('search')
    tableID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheet :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
        check = cur.fetchall()
        sheets = []
        sheetname2 = ''
        for x in check :
            sheetname = base64.b64encode(str(tableID)+ str(x[2]) + str(groupID))
            sheets.append(sheetname)
            if str(sheetname) == str(sheet) :
                sheetname2 =  str(x[2])
        sheetcheck  = []    
        for x in sheets :
            if str(x) == str(sheet) :
                    sheetcheck.append(str(x))          
        if str(sheetcheck[0]) == sheet :            
            query = "PRAGMA table_info('"+ sheet +"')"
            cur.execute(query)
            columns = cur.fetchall()
            cols = []
            for i in columns :
                cols.append(str(i[1]))
            result = []    
            for x  in cols :
                query = "SELECT rowID FROM '"+ sheet + "' WHERE" +'"' + str(x) + '" LIKE ?' 
                cur.execute(query,['%'+search+'%'])
                data = cur.fetchall()
                for i in data :
                    result.append(str(i[0]))
            cur.execute('SELECT tableName FROM table_name WHERE tableID = ? AND groupID = ?',(tableID,groupID))
            tablename = cur.fetchall()
            tablename = str(tablename[0][0])
            return template('sheet-search.tpl',token = token ,users = users ,error = error,cols = cols,sheetname2 = sheetname2,sheet = sheet,search = search ,result = result,tableID = tableID,tablename = tablename)
        else :
            return home(token,error)   
    else :
        return home(token,error)
@route('/add-recored')
def add_recored():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT tableID FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
        tableID = cur.fetchall()
        tableID = str(tableID[0][0])
        cur.execute("SELECT sheetName FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
        sheetname = cur.fetchall()
        for x in range(int(len(sheetname))) :
            sheets = base64.b64encode(tableID + str(sheetname[x][0]) + groupID)
            if sheets == sheet :
                sheetname = sheetname[x][0] 
        query = "PRAGMA table_info('"+ sheet +"')"
        cur.execute(query)
        data = cur.fetchall()
        return template("add-recored.tpl",users = users,token = token, error = error,tablename = tablename,sheet = sheet,data = data ,sheetname = sheetname )
    else:
        return home(token,error)    
@post('/add-recored')
def add_r():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    cols = request.POST.getall('cols')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT tableID FROM table_name WHERE tableName = ? AND groupID = ?",(tablename,groupID))
        tableID = cur.fetchall()
        tableID = str(tableID[0][0])
        valst = ''
        for x in cols :
            valst = valst + "?,"    
        valst = valst[:-1]                
        cur.execute("INSERT INTO '"+ sheet + "' VALUES (null,"+valst+")",cols)
        con.commit()
        redirect("/sheet-view?token="+token+"&tablename="+tablename+"&sheet="+sheet +"&error=yes")
    else:
        return home(token,error)           
@route('/delete-row')
def delete_row() :
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    rowID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)
    if not rowID:
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("DELETE FROM '" + sheet +"' WHERE rowID = ?",[rowID])
        con.commit()
        error = "yes"
        redirect("/sheet-view?token="+token+"&tablename="+tablename+"&sheet="+sheet +"&error=yes")
    else :
        return home(token,error) 
@route('/edite-recored')
def edite_recored():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    rowID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)
    if not rowID:
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        cur.execute("SELECT * FROM '" + sheet + "' WHERE rowID = ?",[rowID])
        data = cur.fetchall()
        query = "PRAGMA table_info('"+ sheet +"')"
        cur.execute(query)
        cols = cur.fetchall()
        return template("edite-recored.tpl",users = users, token = token,error = error,sheet = sheet,tablename= tablename,rowID = rowID,data= data,cols = cols )
    else :
        return home(token,error)          
@post('/edite-recored')
def edite_recored2():
    token = request.query.token
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    tablename = request.query.tablename
    tablename2 = tablename
    sheet = request.query.sheet
    rowID = request.query.id
    data = request.POST.getall('cols')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tablename :
        return home(token,error)
    if not sheet :
        return home(token,error)
    if not rowID:
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()   
    if users :
        groupID = users[0][3]
        query = "PRAGMA table_info('"+ sheet +"')"
        cur.execute(query)
        cols = cur.fetchall()
        array = []
        for x in range(int(len(cols))) :
            if str(cols[x][1]) != "rowID" :
                array.append(str(cols[x][1]))
    
        ii = ''     
        for i in range(int(len(data))) :
            ii = ii + "'" + str(array[i]) + "' = ?,"
        ii = ii[:-1]
        data.append(rowID)
        cur.execute("UPDATE '" + sheet + "' SET " + ii + "WHERE rowID =?",data)
        con.commit()
        redirect("/sheet-view?token="+token+"&tablename="+tablename+"&sheet="+sheet +"&error=yes")       
    else :
        return home(token,error)
@route('/table-setting')
def table_setting():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT tableID,tableName FROM table_name WHERE groupID = ?",[groupID])
            data = cur.fetchall()
            return template("table-setting.tpl",token = token ,users = users,data = data,error = error)
    else :
        return home(token,error) 
@route('/table-edit')
def table_edit() :
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT tableID,tableName FROM table_name WHERE tableID = ?",[tableID])
            tablename = cur.fetchall()
            cur.execute("SELECT * FROM sheets WHERE tableID = ?",[tableID])
            data = cur.fetchall()
            return template("table-edit.tpl",token = token,users = users,data = data,tablename = tablename,tableID = tableID,error = error)
        else :
            return home(token,error)
    else :
        return home(token,error)
@post('/table-edit')
def change_tablename():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    tablename2 = request.forms.get("tablename")
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT tableID,tableName FROM table_name WHERE tableName = ? AND groupID = ?",(tablename2,groupID))
            tablename = cur.fetchall()
            cur.execute("SELECT * FROM sheets WHERE tableID = ?",[tableID])
            data = cur.fetchall()
            if not tablename2 :
                cur.execute("SELECT tableID,tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall() 
                error = "no_tablename"
                return template("table-edit.tpl",token = token,users = users,data = data,tablename = tablename,tableID = tableID,error = error)
            if tablename :
                cur.execute("SELECT tableID,tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall() 
                error = "used_tablename"
                return template("table-edit.tpl",token = token,users = users,data = data,tablename = tablename,tableID = tableID,error = error)   
            cur.execute("UPDATE table_name SET tableName = ? WHERE tableID = ?",(tablename2,tableID))
            con.commit()
            cur.execute("SELECT tableID,tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            tablename = cur.fetchall() 
            error = "yes"
            return template("table-edit.tpl",token = token,users = users,data = data,tablename = tablename,tableID = tableID,error = error)
        else:
            return home(token,error)        
    else :
        return home(token,error)                        
@route('/sheet-edit')
def sheet_edite():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheetID :    
        return home(token,error)
    if not sheetname :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT * FROM sheets WHERE groupID = ? AND tableID = ?",(groupID,tableID))  
            check = cur.fetchall()
            for i in check :
                sheet = base64.b64encode(str(i[1]) + str(i[2]) + str(i[3])) 
                if sheet == sheetname :
                    sheet = str(i[2])   
                    break
            cur.execute("SELECT * FROM sheets WHERE sheetName = ? AND tableID = ? AND groupID = ?",(sheet,tableID,groupID))
            check = cur.fetchall()        
            if check :    
                cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                query = "PRAGMA table_info('"+ sheetname +"')"
                cur.execute(query)
                cols = cur.fetchall()
                return template("sheet-edite.tpl",token = token,error = error,users = users,sheetname = sheetname,tableID = tableID,sheetID = sheetID,sheet = sheet,tablename = tablename,cols=cols)
            else :
                return home(token,error)   
        else:
            return home(token,error)            
    else :
        return home(token,error)
@post('/sheet-changename')
def change_sheetname():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    sheetname2 = request.forms.get('sheet')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheetID :
        return home(token,error)    
    if not sheetname :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            if not sheetname2 :
                error = "no_sheetname"
                cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                query = "PRAGMA table_info('"+ sheetname +"')"
                cur.execute(query)
                cols = cur.fetchall()
                sheet = sheetname2
                return template("sheet-edite.tpl",token = token,error = error,users = users,sheetname = sheetname,tableID = tableID,sheetID = sheetID,sheet = sheet,tablename = tablename,cols=cols)
 
            cur.execute("SELECT * FROM sheets WHERE sheetName = ? and groupID = ? and tableID = ?",(sheetname2,groupID,tableID))
            check = cur.fetchall()
            if check :
                error = "used_sheetname"
                cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                query = "PRAGMA table_info('"+ sheetname +"')"
                cur.execute(query)
                cols = cur.fetchall()
                sheet = sheetname2
                return template("sheet-edite.tpl",token = token,error = error,users = users,sheetname = sheetname,tableID = tableID,sheetID = sheetID,sheet = sheet,tablename = tablename,cols=cols)
            cur.execute("UPDATE sheets SET sheetName = ? WHERE sheetID = ? AND groupID = ? AND tableID = ? ",(sheetname2,sheetID,groupID,tableID))
            con.commit()
            sheet = base64.b64encode(tableID + sheetname2 + groupID)
            if str(sheetname) == str(sheet) :
                error = "same_sheet"
                cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                query = "PRAGMA table_info('"+ sheetname +"')"
                cur.execute(query)
                cols = cur.fetchall()
                sheet = sheetname2
                return template("sheet-edite.tpl",token = token,error = error,users = users,sheetname = sheetname,sheetID = sheetID,tableID = tableID,sheet = sheet,tablename = tablename,cols=cols)
            else :    
                query = "ALTER TABLE '" + sheetname + "' RENAME TO '" + sheet + "'"
                cur.execute(query)
                con.commit()
                error = "yes"
                cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                query = "PRAGMA table_info('"+ sheetname +"')"
                cur.execute(query)
                cols = cur.fetchall()
                redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error=yes")
        else :
            return home(token,error)        
    else :
        return home(token,error)                   
@route('/sheet-colname')
@post('/sheet-colname')
def change_colname():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    column1 = request.forms.get('colname')
    column2 = request.forms.get('col')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not sheetID :
        return home(token,error)    
    if not sheetname :
        return home(token,error)
    if not column1 :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            if not column2 :
                error = "no_colname"
                sheet = sheetname
                redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
            query = "PRAGMA table_info('"+ sheetname +"')"
            cur.execute(query)
            check = cur.fetchall()
            cols = []
            cols2 = []
            for i in check :
                if str(i[1]) == column2 :
                    error = "used_col"
                    sheet = sheetname
                    redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
                if i[1] != check[0][1] :
                    if str(i[1]) == column1 :
                        cols.append(column2+'" TEXT,"')
                        cols2.append(column2+'","')
                    else:        
                        cols.append(str(i[1])+'" TEXT,"')
                        cols2.append(str(i[1])+'","')
            x = int(len(cols)) - 1
            cols[x] = cols[x].replace('TEXT,"',"TEXT")
            cols2[x] = cols2[x].replace(',"','')
            ii = ''
            iix = ''
            for i in cols :
                ii = ii + i
            for i in cols2 :
                iix = iix + i             
            query = "CREATE TABLE '"+sheetname+"tmp'(rowID INTEGER PRIMARY KEY AUTOINCREMENT,"+'"'+ ii +")"    
            cur.execute(query)
            con.commit()
            query = "INSERT INTO '"+sheetname+"tmp'(rowID,"+'"'+iix+") SELECT * FROM '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "DROP TABLE '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "ALTER TABLE '"+sheetname+"tmp' RENAME TO '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            error = "yes"
            sheet = sheetname
            redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@post('/sheet-colreplace')
def replace_column():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    column1 = request.forms.get('colname')
    column2 = request.forms.get('colname2')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetID :
            return home(token,error)    
        if not sheetname :
            return home(token,error)
        if not column1 :
            return home(token,error)
        if not column2 :
            return home(token,error) 
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            query = "PRAGMA table_info('"+ sheetname +"')"
            cur.execute(query)
            check = cur.fetchall()
            cols = []
            cols2 = []
            for i in check :
                if str(i[1]) != str(check[0][1]) :
                    cols.append(str(i[1]))
                if str(i[1]) == column1 :
                    cols2.append(str(i[1]))    
            cnum1 = ''
            cnum2 = ''
            for i in range(int(len(cols))):
                if str(cols[i]) == column1 :
                    cnum1 = i
                if str(cols[i]) == column2 :
                    cnum2 = i    
            cols[cnum1] = cols[cnum2]
            cols[cnum2] = cols2[0]
            array =[]
            array2 = []
            ii = ''
            iix = ''
            for i in cols :
                array.append(str(i)+'" TEXT,"')
                array2.append(str(i)+'","')
            x = int(len(array)) - 1
            array[x] = array[x].replace('TEXT,"',"TEXT")
            array2[x] = array2[x].replace(',"','')    
            for i in array :
                ii = ii + str(i)
            for i in array2 :
                iix = iix + str(i)       
            query = "CREATE TABLE '"+sheetname+"tmp'"+'(rowID INTEGER PRIMARY KEY AUTOINCREMENT,"'+ ii + ")" 
            cur.execute(query)
            con.commit()
            query = "INSERT INTO '"+sheetname+"tmp'(rowID,"+'"'+iix+") SELECT rowID,"+'"'+ iix+" FROM '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "DROP TABLE '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "ALTER TABLE '"+sheetname+"tmp' RENAME TO '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            error = "yes"
            sheet = sheetname
            redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
        else:
            return home(token,error)    
    else :
        return home(token,error)
@post('/sheet-deletecol')
def delete_column():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    column1 = request.forms.get('colname')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetID :
            return home(token,error)    
        if not sheetname :
            return home(token,error)
        if not column1 :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            query = "PRAGMA table_info('"+ sheetname +"')"
            cur.execute(query)
            check = cur.fetchall()
            cols = []
            cols2 = []
            for i in check :
                if str(i[1]) != str(check[0][1]) :
                    
                    if str(i[1]) != column1 :
                        cols.append(str(i[1]))    
            array =[]
            array2 = []
            ii = ''
            iix = ''
            for i in cols :
                array.append(str(i)+'" TEXT,"')
                array2.append(str(i)+'","')
            x = int(len(array)) - 1
            array[x] = array[x].replace('TEXT,"',"TEXT")
            array2[x] = array2[x].replace(',"','')    
            for i in array :
                ii = ii + str(i)
            for i in array2 :
                iix = iix + str(i)       
            query = "CREATE TABLE '"+sheetname+"tmp'(rowID INTEGER PRIMARY KEY AUTOINCREMENT,"+ '"'+ii + ")"        
            cur.execute(query)
            con.commit()
            query = "INSERT INTO '"+sheetname+"tmp'(rowID,"+'"'+iix+") SELECT rowID,"+'"' +iix+ " FROM '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "DROP TABLE '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            query = "ALTER TABLE '"+sheetname+"tmp' RENAME TO '"+sheetname+"'"
            cur.execute(query)
            con.commit()
            error = "yes"
            sheet = sheetname
            redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
        else:
            return home(token,error)    
    else :
        return home(token,error)
@route('/sheet-addcol')
def add_column():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetID :
            return home(token,error)    
        if not sheetname :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            sheet  = cur.fetchall()
            sheetname3 = ''
            for i in sheet :
                sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                if sheetname == sheetname2 :
                    sheetname3 = str(i[2])
            sheetname2 = sheetname3        
            return template('sheet-addcol.tpl',token=token,users=users,error=error,sheetname = sheetname,sheetname2=sheetname2,tableID=tableID,sheetID=sheetID)
        else:
           return home(token,error)
    else:
        return home(token,error)         
@post('/sheet-addcol')
def add_column2():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetID = request.query.sheetID
    sheetname = request.query.sheet
    colname = request.forms.get('colname')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetID :
            return home(token,error)    
        if not sheetname :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            if not colname :
                cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                sheet  = cur.fetchall()
                for i in sheet :
                    sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                    if sheetname == sheetname2 :
                        sheetname2 = str(i[2])
                error = "no_colname"        
                return template('sheet-addcol.tpl',token=token,users=users,error=error,sheetname = sheetname,sheetname2=sheetname2,tableID=tableID,sheetID=sheetID)
            query = "PRAGMA table_info('"+ sheetname +"')"
            cur.execute(query)
            check = cur.fetchall()
            ii = colname.split(',')
            dup_items = set()
            uniq_items = []
            for x in ii :
                if x not in dup_items:
                    uniq_items.append(x)
                    dup_items.add(x)        
            if len(dup_items) != len(ii):
                error = "match_cols"
                cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                sheet  = cur.fetchall()
                for i in sheet :
                    sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                    if sheetname == sheetname2 :
                        sheetname2 = str(i[2])        
                return template('sheet-addcol.tpl',token=token,users=users,error=error,sheetname = sheetname,sheetname2=sheetname2,tableID=tableID,sheetID=sheetID)
            for x in uniq_items :    
                for i in check :
                    if str(i[2]) == str(x) :
                        cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                        sheet  = cur.fetchall()
                        for i in sheet :
                            sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                            if sheetname == sheetname2 :
                                sheetname2 = str(i[2])
                        error = "used_colname"        
                        return template('sheet-addcol.tpl',token=token,users=users,error=error,sheetname = sheetname,sheetname2=sheetname2,tableID=tableID,sheetID=sheetID)
            for x in ii :        
                query = "ALTER TABLE '" + sheetname +"' ADD " +'"'+ str(x) +'"' +" TEXT"
                cur.execute(query)
                con.commit()
            error = "yes"
            sheet = sheetname
            redirect("/sheet-edit?token="+token+"&sheet="+sheet+"&id="+tableID+"&sheetID="+sheetID+"&error="+error)
        else :
            return home(token,error)    
    else :
        return home(token,error)
@route('/sheet-delete')
def delete_sheet():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetname = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetname :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            sheet  = cur.fetchall()
            if sheet :
                for i in sheet :
                    sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                    if sheetname == sheetname2 :
                        sheetname3 = str(i[2])
                sheetname2 = sheetname3                
                return template('sheet-delete.tpl',token= token,users = users,tableID = tableID,sheetname = sheetname,sheetname2 = sheetname2,error = error)
            else :
                return home(token,error)    
        else:
            return home(token,error)        
    else :
        return home(token,error)            
@post('/sheet-delete')
def sheet_delete2():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetname = request.query.sheet
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if not sheetname :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            sheet  = cur.fetchall()
            if sheet :
                for i in sheet :
                    sheetname2 = base64.b64encode(str(i[1])+str(i[2])+str(i[3]))
                    if sheetname == sheetname2 :
                        sheetname3 = str(i[2])
                sheetname2 = sheetname3
                cur.execute("DELETE FROM sheets WHERE sheetName = ? AND tableID = ? AND groupID = ?",(sheetname2,tableID,groupID))
                con.commit()
                query = "DROP TABLE '" +sheetname+"'"
                cur.execute(query)
                con.commit()
                error = "yes"
                return template('sheet-delete.tpl',token= token,users = users,tableID = tableID,sheetname = sheetname,sheetname2 = sheetname2,error = error)        
            else:
                return home(token,error)
        else:
            return home(token,error)
    else :
        return home(token,error)                    
@route('/sheet-add')
def add_sheet():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            check = cur.fetchall()
            if check :
                cur.execute("SELECT tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                tablename = cur.fetchall()
                tablename = tablename[0][0]
                return template("sheet-add.tpl",token = token,error = error,users = users, tableID = tableID,tablename = tablename)
            else :
                return home(token,error)
        else :
            return home(token,error)
    else :
        return home(token,error)            
@post('/sheet-add')
def add_sheet2():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    sheetname = request.forms.get('sheets')
    colsname = request.forms.get('cols')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()   
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if not tableID :
            return home(token,error)
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            tablename = cur.execute("SELECT tableName FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            tablename = cur.fetchall()
            tablename = tablename[0][0]
            if not sheetname :
                error = "no_sheetname"
                return template('sheet-add.tpl',token = token,users = users , error = error,tableID = tableID ,tablename = tablename)
            if not colsname :
                error = "no_cols"
                return template('sheet-add.tpl',token = token,users = users , error = error,tableID = tableID ,tablename = tablename)
            cur.execute("SELECT * FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
            check = cur.fetchall()
            if check :    
                cur.execute("SELECT sheetName FROM sheets WHERE sheetName = ? AND tableID = ? AND groupID = ?",(sheetname,tableID,groupID))
                check_sheetname = cur.fetchall()
                if check_sheetname :
                    error = "used_sheetname"
                    return template('sheet-add.tpl',token = token,users = users , error = error,tableID = tableID , tablename = tablename)
                ii = colsname.split(',')
                dup_items = set()
                uniq_items = []
                for x in ii :
                    if x not in dup_items:
                        uniq_items.append(x)
                        dup_items.add(x)        
                if len(dup_items) != len(ii):
                    error = "match_cols"
                    return template('sheet-add.tpl',token = token,users = users , error = error,tableID = tableID , tablename = tablename)
                colsname = colsname.replace(',','" TEXT,"')
                tablename2 = tablename        
                tablename = tableID + sheetname + groupID
                tablename = base64.b64encode(tablename)
                cur.execute("INSERT INTO sheets (tableID,sheetName,groupID) VALUES (?,?,?)",(tableID,sheetname,groupID))
                con.commit()
                query = "CREATE TABLE IF NOT EXISTS '" +tablename + "' (rowID INTEGER PRIMARY KEY AUTOINCREMENT," +'"' + colsname + '" TEXT)'
                cur.execute(query)
                con.commit()
                error = "yes"
                return template('sheet-add.tpl',token = token,users = users , error = error,tableID = tableID , tablename = tablename2)       
            else :
                return home(token,error)       
        else :
            return home(token,error)
    else :
        return home(token,error)        
@route('/table-delete') 
def table_delete():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            cur.execute("SELECT tableName FROM table_name WHERE tableID = ?",[tableID])
            tablename = cur.fetchall()
            return template("table-delete.tpl",token = token,users = users,tableID = tableID,tablename = tablename,error = error)

        else:
            return home(toke,error)
    else :
        return home(token,error)
@post('/table-delete')
def table_delete2():
    ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
    token = request.query.token
    tableID = request.query.id
    check = request.forms.get('check')
    error = "no"
    if not token :
        return index()
    if token == "not ok":
        return index()
    if not tableID :
        return home(token,error)
    if not check :
        return home(token,error)    
    cur.execute("SELECT * FROM users WHERE token = ? AND ip = ?",(token,ip))
    users = cur.fetchall()
    if users :
        if str(users[0][0]) == users[0][3] :
            groupID = str(users[0][3])
            if check == "yes" :
                cur.execute("DELETE FROM table_name WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                con.commit()
                cur.execute("SELECT * FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                sheets = cur.fetchall()
                array = []
                for i in sheets :
                    sheet = base64.b64encode(str(i[1]) + str(i[2]) + str(i[3]))
                    array.append(sheet)
                cur.execute("DELETE FROM sheets WHERE tableID = ? AND groupID = ?",(tableID,groupID))
                con.commit()
                for i in array :
                    query = "DROP TABLE IF EXISTS '" + str(i) + "'"
                    cur.execute(query)
                    con.commit()
                error = "yes"
                tablename = ''
                return template("table-delete",token = token,users = users,error = error,tableID = tableID)
            if check == "no" :
                redirect("/table-setting?token=" + token)
            else :
                return index()           

        else:
            return home(toke,error)
    else :
        return home(token,error)                                              
@route('/login')        
@post('/login')
def login():
   error = "no"
   username = request.forms.get('user')
   password = request.forms.get('password')
   ip = request.environ['REMOTE_ADDR'] or request.environ.get('HTTP_X_FORWARDED_FOR')
   if not ip :
       return index()
   if not username :
       error = "no_user"
   if not password :
       error = "no_password"
   if error == "no" :

       password = hashlib.md5(password).hexdigest()
       cur.execute("SELECT * FROM users WHERE username = ? and password = ?",(username,password))
       users = cur.fetchall()
       if users:

          userID = str(users[0][0])
          token = password + username
          token = hashlib.md5(token).hexdigest()
          groupID = users[0][3]
          groupName = users[0][5]
          cur.execute("UPDATE users SET token = ? , ip = ? WHERE id = ?",(token,ip,userID))
          con.commit()
          return home(token,error)
       else :
           return index()   
   else :
       return index2(error)
           
#server run :
run(host='localhost', port=8080)
