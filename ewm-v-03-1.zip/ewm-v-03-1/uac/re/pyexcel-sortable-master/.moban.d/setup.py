{%extends "setup.py.jj2"%}

{%block platform_block%}
{%endblock%}