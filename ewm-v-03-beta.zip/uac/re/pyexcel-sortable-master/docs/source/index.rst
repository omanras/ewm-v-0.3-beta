.. include:: ../../README.rst
.. include:: ../../CHANGELOG.rst
