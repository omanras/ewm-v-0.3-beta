Change log
===========

0.0.1 - 12.07.2017
--------------------------------------------------------------------------------

Initial release. Brings csvtotable to pyexcel developers
